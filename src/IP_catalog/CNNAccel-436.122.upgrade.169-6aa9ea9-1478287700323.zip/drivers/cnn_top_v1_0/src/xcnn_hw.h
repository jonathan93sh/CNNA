// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// slv0
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : reserved
// 0x14 : Data signal of status_add
//        bit 31~0 - status_add[31:0] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of status_val
//        bit 31~0 - status_val[31:0] (Read)
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCNN_SLV0_ADDR_STATUS_ADD_DATA 0x14
#define XCNN_SLV0_BITS_STATUS_ADD_DATA 32
#define XCNN_SLV0_ADDR_STATUS_VAL_DATA 0x1c
#define XCNN_SLV0_BITS_STATUS_VAL_DATA 32

