// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// slv0
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : reserved
// 0x14 : Data signal of weight_ctrls
//        bit 31~0 - weight_ctrls[31:0] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of ctrl_image_size
//        bit 31~0 - ctrl_image_size[31:0] (Read/Write)
// 0x20 : reserved
// 0x24 : Data signal of ctrl_row_size_pkg
//        bit 16~0 - ctrl_row_size_pkg[16:0] (Read/Write)
//        others   - reserved
// 0x28 : reserved
// 0x2c : Data signal of ctrl_window_size
//        bit 16~0 - ctrl_window_size[16:0] (Read/Write)
//        others   - reserved
// 0x30 : reserved
// 0x34 : Data signal of ctrl_depth
//        bit 16~0 - ctrl_depth[16:0] (Read/Write)
//        others   - reserved
// 0x38 : reserved
// 0x3c : Data signal of ctrl_stride
//        bit 16~0 - ctrl_stride[16:0] (Read/Write)
//        others   - reserved
// 0x40 : reserved
// 0x44 : Data signal of ctrl_replay
//        bit 16~0 - ctrl_replay[16:0] (Read/Write)
//        others   - reserved
// 0x48 : reserved
// 0x4c : Data signal of ctrl_zeropad
//        bit 16~0 - ctrl_zeropad[16:0] (Read/Write)
//        others   - reserved
// 0x50 : reserved
// 0x54 : Data signal of ctrl_output_channel
//        bit 1~0 - ctrl_output_channel[1:0] (Read/Write)
//        others  - reserved
// 0x58 : reserved
// 0x5c : Data signal of ctrl_stitch_depth
//        bit 16~0 - ctrl_stitch_depth[16:0] (Read/Write)
//        others   - reserved
// 0x60 : reserved
// 0x64 : Data signal of ctrl_stitch_buf_depth
//        bit 16~0 - ctrl_stitch_buf_depth[16:0] (Read/Write)
//        others   - reserved
// 0x68 : reserved
// 0x6c : Data signal of ctrl_db_output
//        bit 1~0 - ctrl_db_output[1:0] (Read/Write)
//        others  - reserved
// 0x70 : reserved
// 0x74 : Data signal of ctrl_image_data
//        bit 1~0 - ctrl_image_data[1:0] (Read/Write)
//        others  - reserved
// 0x78 : reserved
// 0x7c : Data signal of ctrl_pool_depth
//        bit 16~0 - ctrl_pool_depth[16:0] (Read/Write)
//        others   - reserved
// 0x80 : reserved
// 0x84 : Data signal of ctrl_pool_type
//        bit 16~0 - ctrl_pool_type[16:0] (Read/Write)
//        others   - reserved
// 0x88 : reserved
// 0x8c : Data signal of ctrl_pool_N
//        bit 16~0 - ctrl_pool_N[16:0] (Read/Write)
//        others   - reserved
// 0x90 : reserved
// 0x94 : Data signal of ctrl_pool_size
//        bit 16~0 - ctrl_pool_size[16:0] (Read/Write)
//        others   - reserved
// 0x98 : reserved
// 0x9c : Data signal of ctrl_row_N
//        bit 16~0 - ctrl_row_N[16:0] (Read/Write)
//        others   - reserved
// 0xa0 : reserved
// 0xa4 : Data signal of ctrl_acf
//        bit 16~0 - ctrl_acf[16:0] (Read/Write)
//        others   - reserved
// 0xa8 : reserved
// 0xac : Data signal of start
//        bit 15~0 - start[15:0] (Read/Write)
//        others   - reserved
// 0xb0 : reserved
// 0xb4 : Data signal of ready
//        bit 0  - ready[0] (Read)
//        others - reserved
// 0xb8 : reserved
// 0xbc : Data signal of status_add
//        bit 31~0 - status_add[31:0] (Read/Write)
// 0xc0 : reserved
// 0xc4 : Data signal of status_val
//        bit 31~0 - status_val[31:0] (Read)
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCNN_SLV0_ADDR_WEIGHT_CTRLS_DATA          0x14
#define XCNN_SLV0_BITS_WEIGHT_CTRLS_DATA          32
#define XCNN_SLV0_ADDR_CTRL_IMAGE_SIZE_DATA       0x1c
#define XCNN_SLV0_BITS_CTRL_IMAGE_SIZE_DATA       32
#define XCNN_SLV0_ADDR_CTRL_ROW_SIZE_PKG_DATA     0x24
#define XCNN_SLV0_BITS_CTRL_ROW_SIZE_PKG_DATA     17
#define XCNN_SLV0_ADDR_CTRL_WINDOW_SIZE_DATA      0x2c
#define XCNN_SLV0_BITS_CTRL_WINDOW_SIZE_DATA      17
#define XCNN_SLV0_ADDR_CTRL_DEPTH_DATA            0x34
#define XCNN_SLV0_BITS_CTRL_DEPTH_DATA            17
#define XCNN_SLV0_ADDR_CTRL_STRIDE_DATA           0x3c
#define XCNN_SLV0_BITS_CTRL_STRIDE_DATA           17
#define XCNN_SLV0_ADDR_CTRL_REPLAY_DATA           0x44
#define XCNN_SLV0_BITS_CTRL_REPLAY_DATA           17
#define XCNN_SLV0_ADDR_CTRL_ZEROPAD_DATA          0x4c
#define XCNN_SLV0_BITS_CTRL_ZEROPAD_DATA          17
#define XCNN_SLV0_ADDR_CTRL_OUTPUT_CHANNEL_DATA   0x54
#define XCNN_SLV0_BITS_CTRL_OUTPUT_CHANNEL_DATA   2
#define XCNN_SLV0_ADDR_CTRL_STITCH_DEPTH_DATA     0x5c
#define XCNN_SLV0_BITS_CTRL_STITCH_DEPTH_DATA     17
#define XCNN_SLV0_ADDR_CTRL_STITCH_BUF_DEPTH_DATA 0x64
#define XCNN_SLV0_BITS_CTRL_STITCH_BUF_DEPTH_DATA 17
#define XCNN_SLV0_ADDR_CTRL_DB_OUTPUT_DATA        0x6c
#define XCNN_SLV0_BITS_CTRL_DB_OUTPUT_DATA        2
#define XCNN_SLV0_ADDR_CTRL_IMAGE_DATA_DATA       0x74
#define XCNN_SLV0_BITS_CTRL_IMAGE_DATA_DATA       2
#define XCNN_SLV0_ADDR_CTRL_POOL_DEPTH_DATA       0x7c
#define XCNN_SLV0_BITS_CTRL_POOL_DEPTH_DATA       17
#define XCNN_SLV0_ADDR_CTRL_POOL_TYPE_DATA        0x84
#define XCNN_SLV0_BITS_CTRL_POOL_TYPE_DATA        17
#define XCNN_SLV0_ADDR_CTRL_POOL_N_DATA           0x8c
#define XCNN_SLV0_BITS_CTRL_POOL_N_DATA           17
#define XCNN_SLV0_ADDR_CTRL_POOL_SIZE_DATA        0x94
#define XCNN_SLV0_BITS_CTRL_POOL_SIZE_DATA        17
#define XCNN_SLV0_ADDR_CTRL_ROW_N_DATA            0x9c
#define XCNN_SLV0_BITS_CTRL_ROW_N_DATA            17
#define XCNN_SLV0_ADDR_CTRL_ACF_DATA              0xa4
#define XCNN_SLV0_BITS_CTRL_ACF_DATA              17
#define XCNN_SLV0_ADDR_START_DATA                 0xac
#define XCNN_SLV0_BITS_START_DATA                 16
#define XCNN_SLV0_ADDR_READY_DATA                 0xb4
#define XCNN_SLV0_BITS_READY_DATA                 1
#define XCNN_SLV0_ADDR_STATUS_ADD_DATA            0xbc
#define XCNN_SLV0_BITS_STATUS_ADD_DATA            32
#define XCNN_SLV0_ADDR_STATUS_VAL_DATA            0xc4
#define XCNN_SLV0_BITS_STATUS_VAL_DATA            32

