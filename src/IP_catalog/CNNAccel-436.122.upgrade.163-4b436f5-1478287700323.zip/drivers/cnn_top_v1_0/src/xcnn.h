// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XCNN_H
#define XCNN_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xcnn_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Slv0_BaseAddress;
} XCnn_Config;
#endif

typedef struct {
    u32 Slv0_BaseAddress;
    u32 IsReady;
} XCnn;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XCnn_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XCnn_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XCnn_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XCnn_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XCnn_Initialize(XCnn *InstancePtr, u16 DeviceId);
XCnn_Config* XCnn_LookupConfig(u16 DeviceId);
int XCnn_CfgInitialize(XCnn *InstancePtr, XCnn_Config *ConfigPtr);
#else
int XCnn_Initialize(XCnn *InstancePtr, const char* InstanceName);
int XCnn_Release(XCnn *InstancePtr);
#endif


void XCnn_SetWeight_ctrls(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetWeight_ctrls(XCnn *InstancePtr);
void XCnn_SetCtrl_image_size(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_image_size(XCnn *InstancePtr);
void XCnn_SetCtrl_row_size_pkg(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_row_size_pkg(XCnn *InstancePtr);
void XCnn_SetCtrl_window_size(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_window_size(XCnn *InstancePtr);
void XCnn_SetCtrl_depth(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_depth(XCnn *InstancePtr);
void XCnn_SetCtrl_stride(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_stride(XCnn *InstancePtr);
void XCnn_SetCtrl_replay(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_replay(XCnn *InstancePtr);
void XCnn_SetCtrl_zeropad(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_zeropad(XCnn *InstancePtr);
void XCnn_SetCtrl_output_channel(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_output_channel(XCnn *InstancePtr);
void XCnn_SetCtrl_stitch_depth(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_stitch_depth(XCnn *InstancePtr);
void XCnn_SetCtrl_stitch_buf_depth(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_stitch_buf_depth(XCnn *InstancePtr);
void XCnn_SetCtrl_db_output(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_db_output(XCnn *InstancePtr);
void XCnn_SetCtrl_image_data(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_image_data(XCnn *InstancePtr);
void XCnn_SetCtrl_pool_depth(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_pool_depth(XCnn *InstancePtr);
void XCnn_SetCtrl_pool_type(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_pool_type(XCnn *InstancePtr);
void XCnn_SetCtrl_pool_n(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_pool_n(XCnn *InstancePtr);
void XCnn_SetCtrl_pool_size(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_pool_size(XCnn *InstancePtr);
void XCnn_SetCtrl_row_n(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_row_n(XCnn *InstancePtr);
void XCnn_SetCtrl_acf(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetCtrl_acf(XCnn *InstancePtr);
void XCnn_SetStart(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetStart(XCnn *InstancePtr);
u32 XCnn_GetReady(XCnn *InstancePtr);
void XCnn_SetStatus_add(XCnn *InstancePtr, u32 Data);
u32 XCnn_GetStatus_add(XCnn *InstancePtr);
u32 XCnn_GetStatus_val(XCnn *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
