// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xcnn.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XCnn_CfgInitialize(XCnn *InstancePtr, XCnn_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Slv0_BaseAddress = ConfigPtr->Slv0_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XCnn_SetWeight_ctrls(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_WEIGHT_CTRLS_DATA, Data);
}

u32 XCnn_GetWeight_ctrls(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_WEIGHT_CTRLS_DATA);
    return Data;
}

void XCnn_SetCtrl_image_size(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_IMAGE_SIZE_DATA, Data);
}

u32 XCnn_GetCtrl_image_size(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_IMAGE_SIZE_DATA);
    return Data;
}

void XCnn_SetCtrl_row_size_pkg(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_ROW_SIZE_PKG_DATA, Data);
}

u32 XCnn_GetCtrl_row_size_pkg(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_ROW_SIZE_PKG_DATA);
    return Data;
}

void XCnn_SetCtrl_window_size(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_WINDOW_SIZE_DATA, Data);
}

u32 XCnn_GetCtrl_window_size(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_WINDOW_SIZE_DATA);
    return Data;
}

void XCnn_SetCtrl_depth(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_DEPTH_DATA, Data);
}

u32 XCnn_GetCtrl_depth(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_DEPTH_DATA);
    return Data;
}

void XCnn_SetCtrl_stride(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_STRIDE_DATA, Data);
}

u32 XCnn_GetCtrl_stride(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_STRIDE_DATA);
    return Data;
}

void XCnn_SetCtrl_replay(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_REPLAY_DATA, Data);
}

u32 XCnn_GetCtrl_replay(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_REPLAY_DATA);
    return Data;
}

void XCnn_SetCtrl_zeropad(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_ZEROPAD_DATA, Data);
}

u32 XCnn_GetCtrl_zeropad(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_ZEROPAD_DATA);
    return Data;
}

void XCnn_SetCtrl_output_channel(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_OUTPUT_CHANNEL_DATA, Data);
}

u32 XCnn_GetCtrl_output_channel(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_OUTPUT_CHANNEL_DATA);
    return Data;
}

void XCnn_SetCtrl_stitch_depth(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_STITCH_DEPTH_DATA, Data);
}

u32 XCnn_GetCtrl_stitch_depth(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_STITCH_DEPTH_DATA);
    return Data;
}

void XCnn_SetCtrl_stitch_buf_depth(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_STITCH_BUF_DEPTH_DATA, Data);
}

u32 XCnn_GetCtrl_stitch_buf_depth(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_STITCH_BUF_DEPTH_DATA);
    return Data;
}

void XCnn_SetCtrl_db_output(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_DB_OUTPUT_DATA, Data);
}

u32 XCnn_GetCtrl_db_output(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_DB_OUTPUT_DATA);
    return Data;
}

void XCnn_SetCtrl_image_data(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_IMAGE_DATA_DATA, Data);
}

u32 XCnn_GetCtrl_image_data(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_IMAGE_DATA_DATA);
    return Data;
}

void XCnn_SetCtrl_pool_depth(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_POOL_DEPTH_DATA, Data);
}

u32 XCnn_GetCtrl_pool_depth(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_POOL_DEPTH_DATA);
    return Data;
}

void XCnn_SetCtrl_pool_type(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_POOL_TYPE_DATA, Data);
}

u32 XCnn_GetCtrl_pool_type(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_POOL_TYPE_DATA);
    return Data;
}

void XCnn_SetCtrl_pool_n(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_POOL_N_DATA, Data);
}

u32 XCnn_GetCtrl_pool_n(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_POOL_N_DATA);
    return Data;
}

void XCnn_SetCtrl_pool_size(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_POOL_SIZE_DATA, Data);
}

u32 XCnn_GetCtrl_pool_size(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_POOL_SIZE_DATA);
    return Data;
}

void XCnn_SetCtrl_row_n(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_ROW_N_DATA, Data);
}

u32 XCnn_GetCtrl_row_n(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_ROW_N_DATA);
    return Data;
}

void XCnn_SetCtrl_acf(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_ACF_DATA, Data);
}

u32 XCnn_GetCtrl_acf(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_CTRL_ACF_DATA);
    return Data;
}

void XCnn_SetStart(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_START_DATA, Data);
}

u32 XCnn_GetStart(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_START_DATA);
    return Data;
}

u32 XCnn_GetReady(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_READY_DATA);
    return Data;
}

void XCnn_SetStatus_add(XCnn *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_WriteReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_STATUS_ADD_DATA, Data);
}

u32 XCnn_GetStatus_add(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_STATUS_ADD_DATA);
    return Data;
}

u32 XCnn_GetStatus_val(XCnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_ReadReg(InstancePtr->Slv0_BaseAddress, XCNN_SLV0_ADDR_STATUS_VAL_DATA);
    return Data;
}

